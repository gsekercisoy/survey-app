
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Survey-App</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
              
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Welcome to Dashboard</h2>

        <table id="surveysTable" class="table table-bordered">
            <thead>
                <tr>
                    <th>Anket No</th>
                    <th>Anket Adı</th>
                    <th>Durum</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($survey->id); ?></td>
                    <td><?php echo e($survey->survey_name); ?></td>
                    <td>
                        <?php
                            $userSurveyStatus = \App\Models\UserSurveyStatus::where('user_id', auth()->user()->id)
                                ->where('survey_id', $survey->id)
                                ->first();
                        ?>

                        <?php if($userSurveyStatus && $userSurveyStatus->question_status === 0): ?>
                            Anket tamamlandı
                        <?php elseif(strtotime($survey->end_date) < strtotime(now())): ?>
                            Anket süresi doldu
                        <?php else: ?>
                            <a href="survey/<?php echo e($survey->id); ?>" class="btn btn-success">Başla</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#surveysTable').DataTable();
        });
    </script>

</body>
</html>
<?php /**PATH C:\Users\acrom\Desktop\test\survey-app\resources\views/dashboard.blade.php ENDPATH**/ ?>