<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Survey-App</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
              
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <h3><?php echo e($survey->survey_name); ?></h3>

        <form method="POST" action="<?php echo e(route('answer')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="survey_id" value="<?php echo e($survey->id); ?>">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Soru No</th>
                        <th>Soru</th>
                        <th>Cevap</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($question->id); ?></td>
                            <td><?php echo e($question->question); ?></td>
                            <td>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <label class="radio-inline">
                                        <input type="radio" name="answers[<?php echo e($question->id); ?>]" value="<?php echo e($i); ?>"> <?php echo e($i); ?>

                                    </label>
                                <?php endfor; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
<?php /**PATH C:\Users\acrom\Desktop\test\survey-app\resources\views/survey.blade.php ENDPATH**/ ?>